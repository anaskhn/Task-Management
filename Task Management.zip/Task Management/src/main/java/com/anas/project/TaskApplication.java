package com.anas.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**-----------------------------------------------------------------------------------------------------------------
 * 										TASK MANAGEMENT SYSTEM														|
 * 																													|
 *  This is a Spring Boot REST API for task management that provides secure task tracking with role-based access	|
 *  control. The application allows users to create, read, update, and delete tasks using basic authentication, 	|
 *  with separate access levels for admin and user roles. It uses an in-memory H2 database, supports task status 	|
 *  management, and includes comprehensive error handling and endpoint definitions for efficient task management.   |
 * 																													|
 *  @author mohammed.khan																							|
 *																													|
 *------------------------------------------------------------------------------------------------------------------
 */


@SpringBootApplication(scanBasePackages = {"com.anas"})
public class TaskApplication{

	public static void main(String[] args) {
		SpringApplication.run(TaskApplication.class, args);
	}
}
