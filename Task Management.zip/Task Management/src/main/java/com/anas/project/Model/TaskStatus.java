package com.anas.project.Model;

public enum TaskStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED
}