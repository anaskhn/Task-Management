# Task Management REST API

## Overview

This is a robust Spring Boot REST API for task management, featuring secure task tracking with role-based access control. The application allows users to create, read, update, and delete tasks with built-in authentication and validation.

## Features

- RESTful API for task management
- Basic Authentication
- Role-based access control
- Task CRUD operations
- Input validation
- Error handling
- In-memory H2 database for easy testing

## Technology Stack

- Java 8+
- Spring Boot 2.x
- Spring Security
- Spring Data JPA
- H2 Database
- Lombok
- JUnit 5

## Prerequisites

- Java 8 or higher
- Maven 3.6+

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/task-management-api.git
cd task-management-api
```

2. Build the project:
```bash
mvn clean install
```

3. Run the application:
```bash
mvn spring-boot:run
```

## API Endpoints

### Authentication

- **Users**:
  - Admin: username `admin`, password `admin123`
  - User: username `user`, password `user123`

### Task Endpoints

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| GET | `/api/tasks` | Retrieve all tasks | USER, ADMIN |
| GET | `/api/tasks/{id}` | Retrieve specific task | USER, ADMIN |
| POST | `/api/tasks` | Create new task | ADMIN |
| PUT | `/api/tasks/{id}` | Update existing task | ADMIN |
| DELETE | `/api/tasks/{id}` | Delete a task | ADMIN |
| PATCH | `/api/tasks/{id}/complete` | Mark task as complete | USER, ADMIN |

## Postman/Curl Examples

### Get All Tasks
```bash
curl -u user:user123 http://localhost:8080/api/tasks
```

### Create Task (Admin Only)
```bash
curl -u admin:admin123 -X POST http://localhost:8080/api/tasks \
  -H "Content-Type: application/json" \
  -d '{
    "title":"Complete Project", 
    "description":"Finish REST API development", 
    "dueDate":"2024-12-31"
  }'
```

## Task Model

```json
{
  "id": 1,
  "title": "Task Title",
  "description": "Task Description",
  "dueDate": "2024-12-31",
  "status": "PENDING",
  "createdAt": "2024-01-15T10:30:00",
  "updatedAt": "2024-01-15T10:30:00"
}
```

### Task Status Enum
- `PENDING`
- `IN_PROGRESS`
- `COMPLETED`

## Security Configuration

- Basic Authentication
- Role-based access
  - ADMIN: Full CRUD operations
  - USER: Read and update tasks

## Error Handling

The API provides structured error responses:
- 404 Not Found: When a task is not found
- 400 Bad Request: Validation errors
- 401 Unauthorized: Authentication failures

## Testing

Run unit tests:
```bash
mvn test
```

## Configuration

Key configuration files:
- `application.properties`: Database and server configuration
- `SecurityConfig.java`: Security settings
- `pom.xml`: Project dependencies

## Logging

The application uses standard Spring Boot logging. Log levels can be configured in `application.properties`.

## Database

- In-memory H2 database
- Accessible at `/h2-console`
- JDBC URL: `jdbc:h2:mem:taskdb`
- Username: `sa`
- Password: (blank)

## Potential Improvements

- Add database persistence (MySQL/PostgreSQL)
- Implement more advanced user management
- Add pagination for task listing
- Create more comprehensive test coverage

## Troubleshooting

- Ensure Java 8+ is installed
- Check Maven dependencies
- Verify network ports are available


## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## Contact

Anas Khan - anaskhan010502@gmail.com

Project Link: [https://github.com/anaskhn/Task-Management](https://github.com/anaskhn/Task-Management)